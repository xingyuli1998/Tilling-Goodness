Note:This document just introduce how to use each file in the package. 
The document that describe the features of the system named: conclusion and the relative path is: readme\conclusion.docx
# Project blue plan
path: readme\connnection_blue_plan.png

# Software used in the experiment
* Arduino IDE (download from:https://www.arduino.cc/en/software)
* visual studio (download from :https://code.visualstudio.com/)

# Download all the document
Open up terminal and clone the  repo:

```
cd /home/pi
git clone https://github.com/xingyuli1998/pi_test.git
```

# Make you own Arduino and How it works  
Set up the Arduino and use it to read the temperature and the humidity values from the DHT11. Here, I use Arduino to read data as sometimes Pi will make some errors.The water level sensor will read the data from the sensor and control the water pump to add water in the tank. 

```
<Adruino_serial_port = /dev/ttyACM0>
<baudRate = 9600>
```
## Preconditions

* Arduino UNO
* DHT11 sensor
* 12V water pump
* Water level sensor(replace by infrared sensor briefly)
* Delay

* Python 3 recommended.
    Note: install pip (ensure upload libraries)
* C++ environment 

## Library dependencies
Install the following dependencies to create serial communication between Arduino and Raspberry Pi

```
STEP 1
sudo apt-get update 
sudo apt-get upgrade

sudo apt-get install python-serial
sudo apt-get install rpi.gpio

```
```
STEP 2
sudo apt-get install minicom
sudo minicom -s
*choose serial port setup
*input A and set serial driver:/dev/ttyAMA0
*input E and set speed:9600 8N1
*input F and set Hardware Flow Control:NO

```
```
STEP 3
wget https://pypi.python.org/packages/source/R/RPi.GPIO/RPi.GPIO-0.5.11.tar.gz
tar -xvf RPi.GPIO-0.5.11.tar.gz
cd RPi.GPIO-0.5.11
sudo python setup.py install
cd ~
sudo rm -rf RPi.GPIO-0.*
sudo pip3 install pyserial
sudo pip3 install serial
```
```
STEP 4 (manage Arduino libraries)
open Arduino IDE Tool-->manage library-->search
install the follow libraries:
* DHT sensor library
* Adafruit Unified Sensor

```
## Step 1 –Sensor connection
Connecting all sensors to the Arduino. 
The guidance can see the picture: readme\Arduino_connection.png
As some of the sensors don't in the Tinkercad Library
The real connection shows : readme\real_connection.jpg

## Step 2 –Upload the code to the Arduino
* Use USB cable connect Arduino and Raspberry Pi
* Upload code use Arduino IDE
    code: (sensor_code\sensor_code.ino)

# Make you own Raspberry Pi Camera Stream

Create your own live stream from a Raspberry Pi using the Pi camera module. Build your own applications from here.

## How it works
The Pi streams the output of the camera module over the web via Flask. Devices connected to the same network would be able to access the camera stream via

```
<raspberry_pi_ip:5000> 
```

## Screenshots
| ![Setup](readme/pi-stream-client.jpg) | ![Live Pi Camera Stream](readme/pi-stream-screen-capture.jpg) |
|---|---|
| Pi Setup | Pi - Live Stream |

## Preconditions

* Raspberry Pi 4, 2GB is recommended for optimal performance. However you can use a Pi 3 or older, you may see a increase in latency.
* Raspberry Pi 4 Camera Module or Pi HQ Camera Module (Newer version)
* Python 3 recommended.
* Mouse, keyboard, and display
* Radiator
* Wire connection and WIFI

## Library dependencies
Install the following dependencies to create camera stream.

```
sudo apt-get update 
sudo apt-get upgrade

sudo apt-get install libatlas-base-dev
sudo apt-get install libjasper-dev
sudo apt-get install libqtgui4 
sudo apt-get install libqt4-test
sudo apt-get install libhdf5-dev

sudo pip3 install flask
sudo pip3 install numpy
sudo pip3 install opencv-contrib-python
sudo pip3 install imutils
sudo pip3 install opencv-python
```

pip3 install opencv-python

## Step 1 – Pi Connection
* Connect mouse, keyboard and Arduion through USB port
* Connect display through micro HDMI
* Connect Internet cable to the Pi
* Connect Pi camera 
Note: Real connection picture: readme\pi_connection.jpg


# Launch Web Stream

Note: Creating an Autostart of the main.py script is recommended to keep the stream running on bootup.
```bash cd modules
sudo python3 /home/pi/pi-camera-stream-flask/main.py
```

# Autostar Pi 

Optional: A good idea is to make the the camera stream auto start at bootup of your pi. You will now not need to re-run the script every time you want to create the stream. You can do this by going editing the /etc/profile to:

```
sudo nano /etc/profile
```

Go the end of the and add the following (from above):

```
sudo python3 /home/pi/pi-camera-stream-flask/main.py
```

This would cause the following terminal command to auto-start each time the Raspberry Pi boots up. This in effect creates a headless setup - which would be accessed via SSH. 
Note: make sure SSH is enabled.

# Show picture
When press the green button : readme\green_button.png
The pictrue can be saved on the desktop : readme\image.png



